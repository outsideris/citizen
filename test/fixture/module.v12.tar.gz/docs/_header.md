# Azure Storage Account Terraform Module

This module deploys Azure Storage account into a subscription/resource group and configures firewall to allow access from all subnets in the subscription and from predefined IP range (express route circuits, VPN breakouts etc).

## Usage

In order to use this module, configure your module resource as per below:

```powershell
module "my_storage_account" {
  source = "https://artifactory.axaxl.app/terraform-modules/storage/azure?ref=v1.0.0" # Not an actual address yet
  # Storage account suffix - only 12 characters allowed
  name = "mysuffix"

  resource_group_name = "xlc-azu-eus2-eng-tfapp-rg-storagedemo"
  location = "eastus2"
}
```