# Azure Storage Account Terraform Module

This module deploys Azure Storage account into a subscription/resource group and configures firewall to allow access from all subnets in the subscription and from predefined IP range (express route circuits, VPN breakouts etc).

## Usage

In order to use this module, configure your module resource as per below:

```powershell
module "my_storage_account" {
  source = "https://artifactory.axaxl.app/terraform-modules/storage/azure?ref=v1.0.0" # Not an actual address yet
  # Storage account suffix - only 12 characters allowed
  name = "mysuffix"

  resource_group_name = "xlc-azu-eus2-eng-tfapp-rg-storagedemo"
  location = "eastus2"
}
```

## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| azurerm | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| name | Name that will be suffixed to azure subscription predefined prefix. Limited to alpha numeric characters with maximum length of 12. | `string` | n/a | yes |
| resource_group_name | Name of the resource group to which to deploy storage account. Must exist first | `string` | n/a | yes |
| ip_rules | List of acceptable IP address to add to storage account | `list(string)` | <pre>[<br>  "128.177.112.96/29",<br>  "128.177.112.104/29",<br>  "85.92.208.0/24",<br>  "62.189.2.0/26",<br>  "62.190.10.0/24",<br>  "193.128.220.0/24",<br>  "193.128.237.0/27",<br>  "128.177.64.0/24",<br>  "103.83.1.0/24",<br>  "118.201.120.128/27",<br>  "63.100.172.0/24",<br>  "199.26.159.0/24",<br>  "140.206.73.112/28",<br>  "58.210.183.128/27",<br>  "210.87.2.248/29",<br>  "210.87.2.240/29",<br>  "13.86.33.223",<br>  "20.37.158.3",<br>  "94.31.7.152/29",<br>  "94.31.7.144/29"<br>]</pre> | no |
| location | Azure location | `string` | `"eastus2"` | no |

## Outputs

| Name | Description |
|------|-------------|
| id | Resource Id that can be used in azurerm resource definitions |
| name | Full name of the storage account after adding the prefix |

